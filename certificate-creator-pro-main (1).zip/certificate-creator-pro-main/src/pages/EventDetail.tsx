import { useEffect, useState, useCallback } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { useAuth } from '@/lib/auth-context';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from 'sonner';
import { 
  Award, 
  ArrowLeft, 
  Calendar, 
  Users, 
  Image as ImageIcon,
} from 'lucide-react';
import TemplateDesigner from '@/components/TemplateDesigner';
import ParticipantUpload from '@/components/ParticipantUpload';
import ParticipantList from '@/components/ParticipantList';
import CertificatesTab from '@/components/CertificatesTab';

interface Event {
  id: string;
  name: string;
  description: string | null;
  event_date: string;
  template_url: string | null;
  template_fields: any[];
}

interface Participant {
  id: string;
  name: string;
  email: string;
  phone: string | null;
  unique_id: string;
}

export default function EventDetail() {
  const { id } = useParams<{ id: string }>();
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const [event, setEvent] = useState<Event | null>(null);
  const [participants, setParticipants] = useState<Participant[]>([]);
  const [loadingData, setLoadingData] = useState(true);
  const [activeTab, setActiveTab] = useState('participants');

  useEffect(() => {
    if (!loading && !user) {
      navigate('/auth');
    }
  }, [user, loading, navigate]);

  useEffect(() => {
    if (user && id) {
      fetchEventData();
    }
  }, [user, id]);

  const fetchEventData = async () => {
    try {
      const { data: eventData, error: eventError } = await supabase
        .from('events')
        .select('*')
        .eq('id', id)
        .single();

      if (eventError) throw eventError;

      setEvent({
        ...eventData,
        template_fields: Array.isArray(eventData.template_fields) ? eventData.template_fields : []
      });

      const { data: participantsData, error: participantsError } = await supabase
        .from('participants')
        .select('*')
        .eq('event_id', id)
        .order('created_at', { ascending: false });

      if (participantsError) throw participantsError;

      setParticipants(participantsData || []);
    } catch (error) {
      console.error('Error fetching event:', error);
      toast.error('Failed to load event');
      navigate('/events');
    } finally {
      setLoadingData(false);
    }
  };

  const handleTemplateUpdate = useCallback((templateUrl: string, fields: any[]) => {
    setEvent(prev => prev ? { ...prev, template_url: templateUrl, template_fields: fields } : null);
  }, []);

  const handleParticipantsAdded = useCallback((newParticipants: Participant[]) => {
    setParticipants(prev => [...newParticipants, ...prev]);
  }, []);

  const handleParticipantDeleted = useCallback((participantId: string) => {
    setParticipants(prev => prev.filter(p => p.id !== participantId));
  }, []);

  if (loading || loadingData) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="animate-pulse text-muted-foreground">Loading...</div>
      </div>
    );
  }

  if (!event) return null;

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b bg-card/80 backdrop-blur-lg">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2">
            <Award className="h-8 w-8 text-primary" />
            <span className="text-xl font-bold">CertifyPro</span>
          </Link>
          
          <Link to="/events">
            <Button variant="ghost">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Events
            </Button>
          </Link>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {/* Event Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">{event.name}</h1>
          <div className="flex items-center gap-4 text-muted-foreground">
            <span className="flex items-center gap-1">
              <Calendar className="h-4 w-4" />
              {new Date(event.event_date).toLocaleDateString()}
            </span>
            <span className="flex items-center gap-1">
              <Users className="h-4 w-4" />
              {participants.length} participants
            </span>
          </div>
          {event.description && (
            <p className="mt-2 text-muted-foreground">{event.description}</p>
          )}
        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-6">
            <TabsTrigger value="participants" className="gap-2">
              <Users className="h-4 w-4" />
              Participants
            </TabsTrigger>
            <TabsTrigger value="template" className="gap-2">
              <ImageIcon className="h-4 w-4" />
              Template
            </TabsTrigger>
            <TabsTrigger value="certificates" className="gap-2">
              <Award className="h-4 w-4" />
              Certificates
            </TabsTrigger>
          </TabsList>

          <TabsContent value="participants">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-1">
                <ParticipantUpload 
                  eventId={event.id} 
                  onParticipantsAdded={handleParticipantsAdded}
                />
              </div>
              <div className="lg:col-span-2">
                <ParticipantList 
                  participants={participants}
                  onParticipantDeleted={handleParticipantDeleted}
                />
              </div>
            </div>
          </TabsContent>

          <TabsContent value="template">
            <TemplateDesigner 
              eventId={event.id}
              templateUrl={event.template_url}
              templateFields={event.template_fields}
              onUpdate={handleTemplateUpdate}
            />
          </TabsContent>

          <TabsContent value="certificates">
            <CertificatesTab 
              eventId={event.id}
              hasTemplate={!!event.template_url}
              hasParticipants={participants.length > 0}
              templateFields={event.template_fields}
            />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
