import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '@/lib/auth-context';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  Award, 
  Search, 
  LogOut,
  Download,
  ExternalLink,
  Calendar
} from 'lucide-react';

interface Certificate {
  id: string;
  certificate_id: string;
  issued_at: string;
  pdf_url: string | null;
  participants: {
    name: string;
    email: string;
  };
  events: {
    name: string;
    event_date: string;
  };
}

export default function Certificates() {
  const { user, signOut, loading } = useAuth();
  const navigate = useNavigate();
  const [certificates, setCertificates] = useState<Certificate[]>([]);
  const [loadingCerts, setLoadingCerts] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    if (!loading && !user) {
      navigate('/auth');
    }
  }, [user, loading, navigate]);

  useEffect(() => {
    if (user) {
      fetchCertificates();
    }
  }, [user]);

  const fetchCertificates = async () => {
    try {
      const { data, error } = await supabase
        .from('certificates')
        .select(`
          id,
          certificate_id,
          issued_at,
          pdf_url,
          participants (name, email),
          events (name, event_date)
        `)
        .order('issued_at', { ascending: false });

      if (error) throw error;
      setCertificates((data as any) || []);
    } catch (error) {
      console.error('Error fetching certificates:', error);
    } finally {
      setLoadingCerts(false);
    }
  };

  const handleSignOut = async () => {
    await signOut();
    navigate('/');
  };

  const filteredCertificates = certificates.filter(cert =>
    cert.participants?.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    cert.participants?.email?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    cert.events?.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    cert.certificate_id.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="animate-pulse text-muted-foreground">Loading...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b bg-card/80 backdrop-blur-lg">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2">
            <Award className="h-8 w-8 text-primary" />
            <span className="text-xl font-bold">CertifyPro</span>
          </Link>
          
          <nav className="flex items-center gap-4">
            <Link to="/dashboard">
              <Button variant="ghost">Dashboard</Button>
            </Link>
            <Link to="/events">
              <Button variant="ghost">Events</Button>
            </Link>
            <Button variant="ghost" size="icon" onClick={handleSignOut}>
              <LogOut className="h-5 w-5" />
            </Button>
          </nav>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Certificates</h1>
          <p className="text-muted-foreground">View and manage all issued certificates</p>
        </div>

        {/* Search */}
        <div className="relative mb-6">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search by name, email, event, or certificate ID..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 max-w-md"
          />
        </div>

        {/* Certificates Table */}
        <Card>
          <CardHeader>
            <CardTitle>All Certificates ({filteredCertificates.length})</CardTitle>
          </CardHeader>
          <CardContent>
            {loadingCerts ? (
              <div className="animate-pulse text-muted-foreground py-8 text-center">
                Loading certificates...
              </div>
            ) : filteredCertificates.length === 0 ? (
              <div className="text-center py-12 text-muted-foreground">
                <Award className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>No certificates found</p>
                {!searchQuery && (
                  <Link to="/events">
                    <Button variant="secondary" className="mt-4">
                      Go to Events
                    </Button>
                  </Link>
                )}
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-3 px-4 font-medium">Certificate ID</th>
                      <th className="text-left py-3 px-4 font-medium">Recipient</th>
                      <th className="text-left py-3 px-4 font-medium">Event</th>
                      <th className="text-left py-3 px-4 font-medium">Issued Date</th>
                      <th className="text-right py-3 px-4 font-medium">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredCertificates.map((cert) => (
                      <tr key={cert.id} className="border-b hover:bg-muted/30">
                        <td className="py-3 px-4">
                          <code className="text-sm bg-muted px-2 py-1 rounded">
                            {cert.certificate_id}
                          </code>
                        </td>
                        <td className="py-3 px-4">
                          <div>
                            <p className="font-medium">{cert.participants?.name}</p>
                            <p className="text-sm text-muted-foreground">{cert.participants?.email}</p>
                          </div>
                        </td>
                        <td className="py-3 px-4">
                          <div>
                            <p>{cert.events?.name}</p>
                            <p className="text-sm text-muted-foreground flex items-center gap-1">
                              <Calendar className="h-3 w-3" />
                              {new Date(cert.events?.event_date).toLocaleDateString()}
                            </p>
                          </div>
                        </td>
                        <td className="py-3 px-4 text-muted-foreground">
                          {new Date(cert.issued_at).toLocaleDateString()}
                        </td>
                        <td className="py-3 px-4">
                          <div className="flex items-center justify-end gap-2">
                            <Button variant="ghost" size="sm" asChild>
                              <Link to={`/verify?id=${cert.certificate_id}`} target="_blank">
                                <ExternalLink className="h-4 w-4" />
                              </Link>
                            </Button>
                            {cert.pdf_url && (
                              <Button variant="ghost" size="sm" asChild>
                                <a href={cert.pdf_url} target="_blank" rel="noopener noreferrer">
                                  <Download className="h-4 w-4" />
                                </a>
                              </Button>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
