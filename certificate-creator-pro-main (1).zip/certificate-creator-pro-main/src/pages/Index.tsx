import { Link } from 'react-router-dom';
import { useAuth } from '@/lib/auth-context';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { 
  Award, 
  CheckCircle, 
  Download, 
  QrCode, 
  Shield, 
  Sparkles, 
  Upload,
  ArrowRight 
} from 'lucide-react';

export default function Index() {
  const { user, loading } = useAuth();

  const features = [
    {
      icon: Upload,
      title: 'Bulk Upload',
      description: 'Upload participant data via CSV or add manually with ease.'
    },
    {
      icon: Sparkles,
      title: 'Drag & Drop Designer',
      description: 'Position text fields anywhere on your certificate template.'
    },
    {
      icon: QrCode,
      title: 'QR Verification',
      description: 'Each certificate includes a unique QR code for instant verification.'
    },
    {
      icon: Download,
      title: 'Instant Download',
      description: 'Generate and download certificates as high-quality PDFs.'
    },
    {
      icon: Shield,
      title: 'Secure & Private',
      description: 'Enterprise-grade security for all your certificate data.'
    },
    {
      icon: CheckCircle,
      title: 'Easy Verification',
      description: 'Public verification page for anyone to verify certificates.'
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b bg-card/80 backdrop-blur-lg">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Award className="h-8 w-8 text-primary" />
            <span className="text-xl font-bold">CertifyPro</span>
          </div>
          
          <nav className="flex items-center gap-4">
            <Link to="/verify">
              <Button variant="ghost">Verify Certificate</Button>
            </Link>
            {loading ? (
              <Button variant="outline" disabled>Loading...</Button>
            ) : user ? (
              <Link to="/dashboard">
                <Button>Dashboard</Button>
              </Link>
            ) : (
              <Link to="/auth">
                <Button>Get Started</Button>
              </Link>
            )}
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-hero opacity-5" />
        <div className="container mx-auto px-4 py-20 lg:py-32">
          <div className="max-w-4xl mx-auto text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-accent/50 text-accent-foreground mb-6 animate-fade-in">
              <Sparkles className="h-4 w-4" />
              <span className="text-sm font-medium">Professional Certificate Platform</span>
            </div>
            
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 animate-slide-up" style={{ animationDelay: '0.1s' }}>
              Create Beautiful Certificates
              <span className="block gradient-text">in Minutes</span>
            </h1>
            
            <p className="text-lg md:text-xl text-muted-foreground mb-8 max-w-2xl mx-auto animate-slide-up" style={{ animationDelay: '0.2s' }}>
              Upload your template, add participants, and generate professional certificates 
              with QR code verification. Perfect for events, courses, and achievements.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center animate-slide-up" style={{ animationDelay: '0.3s' }}>
              <Link to={user ? "/dashboard" : "/auth"}>
                <Button variant="hero" size="xl">
                  Start Creating
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
              <Link to="/verify">
                <Button variant="outline" size="xl">
                  Verify a Certificate
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Everything You Need
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Powerful features to create, manage, and verify certificates at scale.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, index) => (
              <Card 
                key={index} 
                className="hover-lift border-border/50 animate-slide-up"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <CardContent className="pt-6">
                  <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                    <feature.icon className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="text-lg font-semibold mb-2">{feature.title}</h3>
                  <p className="text-muted-foreground">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <Card className="bg-gradient-hero text-primary-foreground overflow-hidden">
            <CardContent className="p-8 md:p-12 text-center">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">
                Ready to Get Started?
              </h2>
              <p className="text-lg opacity-90 mb-8 max-w-xl mx-auto">
                Join thousands of organizations creating professional certificates with CertifyPro.
              </p>
              <Link to={user ? "/dashboard" : "/auth"}>
                <Button 
                  variant="secondary" 
                  size="xl"
                  className="bg-card text-card-foreground hover:bg-card/90"
                >
                  Create Your First Certificate
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t py-8">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <Award className="h-6 w-6 text-primary" />
              <span className="font-semibold">CertifyPro</span>
            </div>
            <p className="text-sm text-muted-foreground">
              © {new Date().getFullYear()} CertifyPro. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
