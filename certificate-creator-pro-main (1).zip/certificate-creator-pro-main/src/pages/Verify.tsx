import { useState, useEffect, useRef } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { toast } from 'sonner';
import { Award, CheckCircle, XCircle, Search, Download, ArrowLeft, Loader2 } from 'lucide-react';
import { QRCodeSVG } from 'qrcode.react';

interface TemplateField {
  id: string;
  name: string;
  x: number;
  y: number;
  fontSize: number;
  fontFamily: string;
  color: string;
  fontWeight: string;
}

interface CertificateData {
  certificateId: string;
  participantName: string;
  participantEmail: string;
  eventName: string;
  eventDate: string;
  eventDescription: string | null;
  templateUrl: string;
  templateFields: TemplateField[];
  verifyUrl: string;
  issuedAt: string;
}

export default function Verify() {
  const [searchParams] = useSearchParams();
  const [certificateId, setCertificateId] = useState(searchParams.get('id') || '');
  const [loading, setLoading] = useState(false);
  const [certificateData, setCertificateData] = useState<CertificateData | null>(null);
  const [notFound, setNotFound] = useState(false);
  const certificateRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const id = searchParams.get('id');
    if (id) {
      setCertificateId(id);
      handleVerify(id);
    }
  }, [searchParams]);

  const handleVerify = async (id?: string) => {
    const idToVerify = id || certificateId.trim();
    
    if (!idToVerify) {
      toast.error('Please enter a certificate ID');
      return;
    }

    setLoading(true);
    setCertificateData(null);
    setNotFound(false);

    try {
      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/get-certificate?id=${encodeURIComponent(idToVerify)}`,
        {
          method: 'GET',
          headers: { 'Content-Type': 'application/json' },
        }
      );

      const result = await response.json();

      if (!response.ok) {
        if (response.status === 404) {
          setNotFound(true);
          toast.error('Certificate not found');
        } else {
          throw new Error(result.error || 'Failed to verify certificate');
        }
        return;
      }

      setCertificateData(result);
      toast.success('Certificate verified successfully!');
    } catch (err) {
      console.error('Verification error:', err);
      toast.error('Error verifying certificate');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleVerify();
  };

  const getFieldValue = (fieldName: string): string => {
    if (!certificateData) return '';
    
    const lowerName = fieldName.toLowerCase();
    if (lowerName.includes('name') && !lowerName.includes('event')) {
      return certificateData.participantName;
    }
    if (lowerName.includes('event') && lowerName.includes('name')) {
      return certificateData.eventName;
    }
    if (lowerName.includes('date')) {
      return new Date(certificateData.eventDate).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
      });
    }
    if (lowerName.includes('id') || lowerName.includes('certificate')) {
      return certificateData.certificateId;
    }
    return fieldName;
  };

  const handleDownload = () => {
    window.print();
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 border-b bg-card/80 backdrop-blur-lg print:hidden">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2">
            <Award className="h-8 w-8 text-primary" />
            <span className="text-xl font-bold">CertifyPro</span>
          </Link>
          <Link to="/">
            <Button variant="ghost">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Home
            </Button>
          </Link>
        </div>
      </header>

      <main className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-8 print:hidden">
            <h1 className="text-3xl md:text-4xl font-bold mb-4">Verify Certificate</h1>
            <p className="text-lg text-muted-foreground">
              Enter the certificate ID to verify its authenticity
            </p>
          </div>

          <Card className="mb-8 print:hidden">
            <CardContent className="pt-6">
              <form onSubmit={handleSubmit} className="flex gap-4">
                <Input
                  placeholder="Enter Certificate ID (e.g., CERT-ABC123)"
                  value={certificateId}
                  onChange={(e) => setCertificateId(e.target.value)}
                  className="flex-1"
                />
                <Button type="submit" disabled={loading}>
                  {loading ? (
                    <><Loader2 className="mr-2 h-4 w-4 animate-spin" />Verifying...</>
                  ) : (
                    <><Search className="mr-2 h-4 w-4" />Verify</>
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>

          {certificateData && (
            <div className="space-y-6 animate-scale-in">
              <Card className="border-success/50 bg-success/5 print:hidden">
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-full bg-success/20 flex items-center justify-center">
                      <CheckCircle className="h-6 w-6 text-success" />
                    </div>
                    <div>
                      <CardTitle className="text-success">Certificate Verified</CardTitle>
                      <CardDescription>This certificate is authentic and valid</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-muted-foreground">Certificate ID</p>
                      <p className="font-medium">{certificateData.certificateId}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Issued Date</p>
                      <p className="font-medium">{new Date(certificateData.issuedAt).toLocaleDateString()}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Recipient Name</p>
                      <p className="font-medium">{certificateData.participantName}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Recipient Email</p>
                      <p className="font-medium">{certificateData.participantEmail}</p>
                    </div>
                    <div className="md:col-span-2">
                      <p className="text-sm text-muted-foreground">Event</p>
                      <p className="font-medium">{certificateData.eventName}</p>
                      <p className="text-sm text-muted-foreground">
                        {new Date(certificateData.eventDate).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                  <Button onClick={handleDownload} variant="secondary" className="w-full">
                    <Download className="mr-2 h-4 w-4" />
                    Print / Save as PDF
                  </Button>
                </CardContent>
              </Card>

              {certificateData.templateUrl && (
                <Card className="print:shadow-none print:border-none">
                  <CardHeader className="print:hidden">
                    <CardTitle>Certificate Preview</CardTitle>
                  </CardHeader>
                  <CardContent className="p-0 md:p-6 print:p-0">
                    <div 
                      ref={certificateRef}
                      className="relative w-full overflow-hidden rounded-lg print:rounded-none bg-white"
                      style={{ aspectRatio: '1.414' }}
                    >
                      <img
                        src={certificateData.templateUrl}
                        alt="Certificate Template"
                        className="w-full h-full object-contain"
                        crossOrigin="anonymous"
                      />
                      
                      {certificateData.templateFields.map((field) => (
                        <div
                          key={field.id}
                          className="absolute pointer-events-none"
                          style={{
                            left: `${field.x}%`,
                            top: `${field.y}%`,
                            transform: 'translate(-50%, -50%)',
                            fontSize: `clamp(8px, ${field.fontSize * 0.15}vw, ${field.fontSize}px)`,
                            fontFamily: field.fontFamily,
                            fontWeight: field.fontWeight,
                            color: field.color,
                            whiteSpace: 'nowrap',
                          }}
                        >
                          {getFieldValue(field.name)}
                        </div>
                      ))}

                      <div className="absolute bottom-[3%] right-[3%] bg-white p-2 rounded shadow-lg print:shadow-none">
                        <QRCodeSVG
                          value={certificateData.verifyUrl}
                          size={80}
                          level="M"
                          includeMargin={false}
                        />
                        <p className="text-[6px] text-center text-gray-500 mt-1">Scan to verify</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          )}

          {notFound && (
            <Card className="border-destructive/50 bg-destructive/5 animate-scale-in">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-destructive/20 flex items-center justify-center">
                    <XCircle className="h-6 w-6 text-destructive" />
                  </div>
                  <div>
                    <CardTitle className="text-destructive">Certificate Not Found</CardTitle>
                    <CardDescription>
                      No certificate found with this ID. Please check the ID and try again.
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
            </Card>
          )}
        </div>
      </main>
    </div>
  );
}
