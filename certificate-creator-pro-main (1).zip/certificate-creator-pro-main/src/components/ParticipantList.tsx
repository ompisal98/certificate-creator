import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { toast } from 'sonner';
import { Users, Search, Trash2, Mail, Phone } from 'lucide-react';

interface Participant {
  id: string;
  name: string;
  email: string;
  phone: string | null;
  unique_id: string;
}

interface ParticipantListProps {
  participants: Participant[];
  onParticipantDeleted: (id: string) => void;
}

export default function ParticipantList({ participants, onParticipantDeleted }: ParticipantListProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [deleting, setDeleting] = useState<string | null>(null);

  const handleDelete = async (participant: Participant) => {
    if (!confirm(`Are you sure you want to remove ${participant.name}?`)) {
      return;
    }

    setDeleting(participant.id);

    try {
      const { error } = await supabase
        .from('participants')
        .delete()
        .eq('id', participant.id);

      if (error) throw error;

      onParticipantDeleted(participant.id);
      toast.success('Participant removed');
    } catch (error) {
      console.error('Error deleting participant:', error);
      toast.error('Failed to remove participant');
    } finally {
      setDeleting(null);
    }
  };

  const filteredParticipants = participants.filter(p =>
    p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    p.email.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Users className="h-5 w-5 text-teal" />
          Participants ({participants.length})
        </CardTitle>
        <CardDescription>
          Manage event participants
        </CardDescription>
      </CardHeader>
      <CardContent>
        {participants.length > 0 && (
          <div className="relative mb-4">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search participants..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
        )}

        {participants.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <Users className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>No participants added yet</p>
            <p className="text-sm mt-1">Add participants manually or upload a CSV file</p>
          </div>
        ) : filteredParticipants.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <p>No participants match your search</p>
          </div>
        ) : (
          <div className="space-y-2 max-h-[500px] overflow-y-auto">
            {filteredParticipants.map((participant) => (
              <div
                key={participant.id}
                className="flex items-center justify-between p-3 rounded-lg border hover:bg-accent/30 transition-colors"
              >
                <div className="flex-1 min-w-0">
                  <p className="font-medium truncate">{participant.name}</p>
                  <div className="flex items-center gap-4 text-sm text-muted-foreground">
                    <span className="flex items-center gap-1 truncate">
                      <Mail className="h-3 w-3" />
                      {participant.email}
                    </span>
                    {participant.phone && (
                      <span className="flex items-center gap-1">
                        <Phone className="h-3 w-3" />
                        {participant.phone}
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">
                    ID: {participant.unique_id}
                  </p>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => handleDelete(participant)}
                  disabled={deleting === participant.id}
                  className="text-muted-foreground hover:text-destructive"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
