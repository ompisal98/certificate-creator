import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { toast } from 'sonner';
import { Award, Mail, Loader2 } from 'lucide-react';

interface CertificatesTabProps {
  eventId: string;
  hasTemplate: boolean;
  hasParticipants: boolean;
  templateFields: any[];
}

export default function CertificatesTab({ 
  eventId, 
  hasTemplate, 
  hasParticipants,
  templateFields 
}: CertificatesTabProps) {
  const [generating, setGenerating] = useState(false);
  const [sending, setSending] = useState(false);
  const [certificates, setCertificates] = useState<any[]>([]);
  const [loadingCerts, setLoadingCerts] = useState(true);

  useEffect(() => {
    fetchCertificates();
  }, [eventId]);

  const fetchCertificates = async () => {
    try {
      const { data, error } = await supabase
        .from('certificates')
        .select(`
          *,
          participants (name, email)
        `)
        .eq('event_id', eventId)
        .order('issued_at', { ascending: false });

      if (error) throw error;
      setCertificates(data || []);
    } catch (error) {
      console.error('Error fetching certificates:', error);
    } finally {
      setLoadingCerts(false);
    }
  };

  const handleGenerateCertificates = async () => {
    if (!hasTemplate) {
      toast.error('Please upload a certificate template first');
      return;
    }
    if (!hasParticipants) {
      toast.error('Please add participants first');
      return;
    }

    setGenerating(true);
    toast.info('Generating certificates... This may take a moment.');

    try {
      const { data, error } = await supabase.functions.invoke('generate-certificate', {
        body: { eventId }
      });

      if (error) throw error;

      if (data.generated === 0) {
        toast.info(data.message || 'All participants already have certificates');
      } else {
        toast.success(`Generated ${data.generated} certificates!`);
        fetchCertificates();
      }
    } catch (error: any) {
      console.error('Error generating certificates:', error);
      toast.error(error.message || 'Failed to generate certificates');
    } finally {
      setGenerating(false);
    }
  };

  const handleSendEmails = async () => {
    if (certificates.length === 0) {
      toast.error('No certificates to send');
      return;
    }

    setSending(true);
    toast.info('Sending emails... This may take a moment.');

    try {
      const { data, error } = await supabase.functions.invoke('send-certificates', {
        body: { eventId }
      });

      if (error) throw error;

      if (data.sent > 0) {
        toast.success(`Sent ${data.sent} emails successfully!`);
      }
      if (data.failed > 0) {
        toast.warning(`${data.failed} emails failed to send`);
      }
    } catch (error: any) {
      console.error('Error sending emails:', error);
      toast.error(error.message || 'Failed to send emails');
    } finally {
      setSending(false);
    }
  };

  const canGenerate = hasTemplate && hasParticipants;

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Award className="h-5 w-5 text-teal" />
            Generate Certificates
          </CardTitle>
          <CardDescription>
            Generate certificates with QR codes for all participants
          </CardDescription>
        </CardHeader>
        <CardContent>
          {!hasTemplate && (
            <div className="p-4 rounded-lg bg-warning/10 border border-warning/30 text-warning mb-4">
              <p className="text-sm">Please upload a certificate template first</p>
            </div>
          )}
          {!hasParticipants && (
            <div className="p-4 rounded-lg bg-warning/10 border border-warning/30 text-warning mb-4">
              <p className="text-sm">Please add participants first</p>
            </div>
          )}
          <div className="flex gap-3">
            <Button 
              onClick={handleGenerateCertificates} 
              disabled={!canGenerate || generating}
              variant="teal"
            >
              {generating ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Generating...
                </>
              ) : (
                'Generate Certificates'
              )}
            </Button>
            <Button 
              onClick={handleSendEmails} 
              disabled={certificates.length === 0 || sending}
              variant="outline"
            >
              {sending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Sending...
                </>
              ) : (
                <>
                  <Mail className="mr-2 h-4 w-4" />
                  Send to All
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Issued Certificates ({certificates.length})</CardTitle>
        </CardHeader>
        <CardContent>
          {loadingCerts ? (
            <div className="animate-pulse text-muted-foreground">Loading...</div>
          ) : certificates.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <Award className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>No certificates generated yet</p>
            </div>
          ) : (
            <div className="space-y-3">
              {certificates.map((cert) => (
                <div 
                  key={cert.id}
                  className="flex items-center justify-between p-4 rounded-lg border"
                >
                  <div>
                    <p className="font-medium">{cert.participants?.name}</p>
                    <p className="text-sm text-muted-foreground">{cert.certificate_id}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button variant="ghost" size="sm" asChild>
                      <Link to={`/verify?id=${cert.certificate_id}`} target="_blank">
                        View
                      </Link>
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
