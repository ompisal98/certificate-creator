import { useState, useRef } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from 'sonner';
import { Upload, Plus, FileSpreadsheet, User } from 'lucide-react';

interface ParticipantUploadProps {
  eventId: string;
  onParticipantsAdded: (participants: any[]) => void;
}

export default function ParticipantUpload({ eventId, onParticipantsAdded }: ParticipantUploadProps) {
  const [loading, setLoading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [manualForm, setManualForm] = useState({
    name: '',
    email: '',
    phone: ''
  });

  const generateUniqueId = () => {
    return `P-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`;
  };

  const handleManualAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!manualForm.name.trim() || !manualForm.email.trim()) {
      toast.error('Name and email are required');
      return;
    }

    setLoading(true);

    try {
      const { data, error } = await supabase
        .from('participants')
        .insert({
          event_id: eventId,
          name: manualForm.name.trim(),
          email: manualForm.email.trim(),
          phone: manualForm.phone.trim() || null,
          unique_id: generateUniqueId()
        })
        .select()
        .single();

      if (error) throw error;

      onParticipantsAdded([data]);
      setManualForm({ name: '', email: '', phone: '' });
      toast.success('Participant added successfully!');
    } catch (error: any) {
      console.error('Error adding participant:', error);
      toast.error(error.message || 'Failed to add participant');
    } finally {
      setLoading(false);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const fileExtension = file.name.split('.').pop()?.toLowerCase();
    if (!['csv', 'xlsx', 'xls'].includes(fileExtension || '')) {
      toast.error('Please upload a CSV or Excel file');
      return;
    }

    setLoading(true);

    try {
      const text = await file.text();
      const lines = text.split('\n').filter(line => line.trim());
      
      if (lines.length < 2) {
        toast.error('File must have a header row and at least one data row');
        return;
      }

      // Parse header
      const header = lines[0].split(',').map(h => h.trim().toLowerCase());
      const nameIdx = header.findIndex(h => h.includes('name'));
      const emailIdx = header.findIndex(h => h.includes('email'));
      const phoneIdx = header.findIndex(h => h.includes('phone'));

      if (nameIdx === -1 || emailIdx === -1) {
        toast.error('CSV must have "name" and "email" columns');
        return;
      }

      // Parse data rows
      const participants = [];
      for (let i = 1; i < lines.length; i++) {
        const values = lines[i].split(',').map(v => v.trim().replace(/^"|"$/g, ''));
        const name = values[nameIdx];
        const email = values[emailIdx];
        const phone = phoneIdx !== -1 ? values[phoneIdx] : null;

        if (name && email) {
          participants.push({
            event_id: eventId,
            name,
            email,
            phone: phone || null,
            unique_id: generateUniqueId()
          });
        }
      }

      if (participants.length === 0) {
        toast.error('No valid participants found in file');
        return;
      }

      const { data, error } = await supabase
        .from('participants')
        .insert(participants)
        .select();

      if (error) throw error;

      onParticipantsAdded(data || []);
      toast.success(`Added ${data?.length || 0} participants!`);
      
      // Reset file input
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    } catch (error: any) {
      console.error('Error uploading participants:', error);
      toast.error(error.message || 'Failed to upload participants');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Plus className="h-5 w-5 text-primary" />
          Add Participants
        </CardTitle>
        <CardDescription>
          Upload a CSV file or add participants manually
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="manual">
          <TabsList className="w-full">
            <TabsTrigger value="manual" className="flex-1 gap-2">
              <User className="h-4 w-4" />
              Manual
            </TabsTrigger>
            <TabsTrigger value="upload" className="flex-1 gap-2">
              <FileSpreadsheet className="h-4 w-4" />
              CSV Upload
            </TabsTrigger>
          </TabsList>

          <TabsContent value="manual" className="mt-4">
            <form onSubmit={handleManualAdd} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Name *</Label>
                <Input
                  id="name"
                  placeholder="John Doe"
                  value={manualForm.name}
                  onChange={(e) => setManualForm({ ...manualForm, name: e.target.value })}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Email *</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="john@example.com"
                  value={manualForm.email}
                  onChange={(e) => setManualForm({ ...manualForm, email: e.target.value })}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="phone">Phone</Label>
                <Input
                  id="phone"
                  type="tel"
                  placeholder="+1 234 567 8900"
                  value={manualForm.phone}
                  onChange={(e) => setManualForm({ ...manualForm, phone: e.target.value })}
                />
              </div>
              <Button type="submit" className="w-full" disabled={loading}>
                {loading ? 'Adding...' : 'Add Participant'}
              </Button>
            </form>
          </TabsContent>

          <TabsContent value="upload" className="mt-4">
            <div className="space-y-4">
              <div className="border-2 border-dashed border-border rounded-lg p-6 text-center">
                <Upload className="h-10 w-10 mx-auto mb-4 text-muted-foreground" />
                <p className="text-sm text-muted-foreground mb-2">
                  Upload a CSV file with columns: name, email, phone (optional)
                </p>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".csv,.xlsx,.xls"
                  onChange={handleFileUpload}
                  className="hidden"
                  id="file-upload"
                />
                <Button 
                  type="button" 
                  variant="outline"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={loading}
                >
                  {loading ? 'Uploading...' : 'Choose File'}
                </Button>
              </div>

              <div className="p-4 rounded-lg bg-muted/50">
                <p className="text-sm font-medium mb-2">CSV Format Example:</p>
                <code className="text-xs text-muted-foreground">
                  name,email,phone<br />
                  John Doe,john@example.com,+1234567890<br />
                  Jane Smith,jane@example.com,
                </code>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}
