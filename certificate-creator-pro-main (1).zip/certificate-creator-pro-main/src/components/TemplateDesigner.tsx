import { useState, useRef, useCallback, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/lib/auth-context';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { toast } from 'sonner';
import { 
  Upload, 
  Image as ImageIcon, 
  Plus, 
  Trash2, 
  Move, 
  Type,
  Save
} from 'lucide-react';

interface TemplateField {
  id: string;
  name: string;
  label: string;
  x: number;
  y: number;
  fontSize: number;
  fontWeight: string;
  color: string;
}

interface TemplateDesignerProps {
  eventId: string;
  templateUrl: string | null;
  templateFields: TemplateField[];
  onUpdate: (templateUrl: string, fields: TemplateField[]) => void;
}

const AVAILABLE_FIELDS = [
  { name: 'participant_name', label: 'Participant Name' },
  { name: 'event_name', label: 'Event Name' },
  { name: 'event_date', label: 'Event Date' },
  { name: 'certificate_id', label: 'Certificate ID' },
  { name: 'custom_text', label: 'Custom Text' },
];

export default function TemplateDesigner({ eventId, templateUrl, templateFields, onUpdate }: TemplateDesignerProps) {
  const { user } = useAuth();
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [currentTemplate, setCurrentTemplate] = useState<string | null>(templateUrl);
  const [fields, setFields] = useState<TemplateField[]>(templateFields || []);
  const [draggingField, setDraggingField] = useState<string | null>(null);
  const [selectedField, setSelectedField] = useState<string | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const imageRef = useRef<HTMLImageElement>(null);

  const handleTemplateUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      toast.error('Please upload an image file (PNG, JPG)');
      return;
    }

    setUploading(true);

    try {
      const fileExt = file.name.split('.').pop();
      const fileName = `${user?.id}/${eventId}/template.${fileExt}`;

      const { error: uploadError } = await supabase.storage
        .from('templates')
        .upload(fileName, file, { upsert: true });

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('templates')
        .getPublicUrl(fileName);

      setCurrentTemplate(publicUrl);

      // Update event with template URL
      const { error: updateError } = await supabase
        .from('events')
        .update({ template_url: publicUrl })
        .eq('id', eventId);

      if (updateError) throw updateError;

      onUpdate(publicUrl, fields);
      toast.success('Template uploaded successfully!');
    } catch (error) {
      console.error('Error uploading template:', error);
      toast.error('Failed to upload template');
    } finally {
      setUploading(false);
    }
  };

  const addField = (fieldType: string) => {
    const fieldConfig = AVAILABLE_FIELDS.find(f => f.name === fieldType);
    if (!fieldConfig) return;

    const newField: TemplateField = {
      id: `field-${Date.now()}`,
      name: fieldType,
      label: fieldConfig.label,
      x: 50,
      y: 50,
      fontSize: 24,
      fontWeight: 'bold',
      color: '#000000'
    };

    setFields([...fields, newField]);
  };

  const updateField = (id: string, updates: Partial<TemplateField>) => {
    setFields(fields.map(f => f.id === id ? { ...f, ...updates } : f));
  };

  const removeField = (id: string) => {
    setFields(fields.filter(f => f.id !== id));
    if (selectedField === id) setSelectedField(null);
  };

  const handleMouseDown = (e: React.MouseEvent, fieldId: string) => {
    e.preventDefault();
    setDraggingField(fieldId);
    setSelectedField(fieldId);
  };

  const handleMouseMove = useCallback((e: MouseEvent) => {
    if (!draggingField || !containerRef.current) return;

    const rect = containerRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;

    updateField(draggingField, {
      x: Math.max(0, Math.min(100, x)),
      y: Math.max(0, Math.min(100, y))
    });
  }, [draggingField]);

  const handleMouseUp = useCallback(() => {
    setDraggingField(null);
  }, []);

  useEffect(() => {
    if (draggingField) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleMouseUp);
      return () => {
        window.removeEventListener('mousemove', handleMouseMove);
        window.removeEventListener('mouseup', handleMouseUp);
      };
    }
  }, [draggingField, handleMouseMove, handleMouseUp]);

  const handleSaveFields = async () => {
    setSaving(true);

    try {
      const { error } = await supabase
        .from('events')
        .update({ template_fields: fields as any })
        .eq('id', eventId);

      if (error) throw error;

      onUpdate(currentTemplate || '', fields);
      toast.success('Template fields saved!');
    } catch (error) {
      console.error('Error saving fields:', error);
      toast.error('Failed to save fields');
    } finally {
      setSaving(false);
    }
  };

  const selectedFieldData = fields.find(f => f.id === selectedField);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Template Canvas */}
      <div className="lg:col-span-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <ImageIcon className="h-5 w-5 text-primary" />
              Certificate Template
            </CardTitle>
            <CardDescription>
              Upload a template and drag fields to position them
            </CardDescription>
          </CardHeader>
          <CardContent>
            {!currentTemplate ? (
              <div className="border-2 border-dashed border-border rounded-lg p-12 text-center">
                <Upload className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                <p className="text-muted-foreground mb-4">
                  Upload your certificate template image
                </p>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleTemplateUpload}
                  className="hidden"
                  id="template-upload"
                />
                <Button
                  type="button"
                  onClick={() => document.getElementById('template-upload')?.click()}
                  disabled={uploading}
                >
                  {uploading ? 'Uploading...' : 'Choose Template'}
                </Button>
              </div>
            ) : (
              <div className="space-y-4">
                <div 
                  ref={containerRef}
                  className="relative border rounded-lg overflow-hidden bg-muted/30"
                  style={{ cursor: draggingField ? 'grabbing' : 'default' }}
                >
                  <img
                    ref={imageRef}
                    src={currentTemplate}
                    alt="Certificate template"
                    className="w-full h-auto"
                    draggable={false}
                  />
                  
                  {/* Draggable Fields */}
                  {fields.map((field) => (
                    <div
                      key={field.id}
                      className={`absolute cursor-move select-none px-2 py-1 rounded border-2 transition-colors ${
                        selectedField === field.id 
                          ? 'border-primary bg-primary/10' 
                          : 'border-transparent hover:border-primary/50'
                      }`}
                      style={{
                        left: `${field.x}%`,
                        top: `${field.y}%`,
                        transform: 'translate(-50%, -50%)',
                        fontSize: `${field.fontSize}px`,
                        fontWeight: field.fontWeight,
                        color: field.color
                      }}
                      onMouseDown={(e) => handleMouseDown(e, field.id)}
                      onClick={() => setSelectedField(field.id)}
                    >
                      <span className="flex items-center gap-1">
                        <Move className="h-3 w-3" />
                        {`{${field.label}}`}
                      </span>
                    </div>
                  ))}
                </div>

                <div className="flex gap-2">
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleTemplateUpload}
                    className="hidden"
                    id="template-replace"
                  />
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => document.getElementById('template-replace')?.click()}
                    disabled={uploading}
                  >
                    Replace Template
                  </Button>
                  <Button
                    variant="teal"
                    size="sm"
                    onClick={handleSaveFields}
                    disabled={saving}
                  >
                    <Save className="h-4 w-4 mr-2" />
                    {saving ? 'Saving...' : 'Save Fields'}
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Field Controls */}
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Type className="h-5 w-5 text-teal" />
              Add Fields
            </CardTitle>
            <CardDescription>
              Click to add fields to your template
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-2">
            {AVAILABLE_FIELDS.map((field) => (
              <Button
                key={field.name}
                variant="outline"
                className="w-full justify-start"
                onClick={() => addField(field.name)}
                disabled={!currentTemplate}
              >
                <Plus className="h-4 w-4 mr-2" />
                {field.label}
              </Button>
            ))}
          </CardContent>
        </Card>

        {/* Field Properties */}
        {selectedFieldData && (
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Field Properties</CardTitle>
              <CardDescription>{selectedFieldData.label}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Font Size</Label>
                <Input
                  type="number"
                  value={selectedFieldData.fontSize}
                  onChange={(e) => updateField(selectedFieldData.id, { fontSize: parseInt(e.target.value) || 24 })}
                  min={8}
                  max={72}
                />
              </div>
              <div className="space-y-2">
                <Label>Font Weight</Label>
                <select
                  value={selectedFieldData.fontWeight}
                  onChange={(e) => updateField(selectedFieldData.id, { fontWeight: e.target.value })}
                  className="w-full h-10 px-3 rounded-md border border-input bg-background"
                >
                  <option value="normal">Normal</option>
                  <option value="bold">Bold</option>
                </select>
              </div>
              <div className="space-y-2">
                <Label>Color</Label>
                <Input
                  type="color"
                  value={selectedFieldData.color}
                  onChange={(e) => updateField(selectedFieldData.id, { color: e.target.value })}
                  className="h-10 p-1"
                />
              </div>
              <Button
                variant="destructive"
                size="sm"
                className="w-full"
                onClick={() => removeField(selectedFieldData.id)}
              >
                <Trash2 className="h-4 w-4 mr-2" />
                Remove Field
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Active Fields */}
        {fields.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Active Fields</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {fields.map((field) => (
                  <div
                    key={field.id}
                    className={`flex items-center justify-between p-2 rounded cursor-pointer transition-colors ${
                      selectedField === field.id ? 'bg-primary/10' : 'hover:bg-muted'
                    }`}
                    onClick={() => setSelectedField(field.id)}
                  >
                    <span className="text-sm">{field.label}</span>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-6 w-6"
                      onClick={(e) => {
                        e.stopPropagation();
                        removeField(field.id);
                      }}
                    >
                      <Trash2 className="h-3 w-3" />
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
