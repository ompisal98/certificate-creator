-- Create app_role enum for admin roles
CREATE TYPE public.app_role AS ENUM ('admin', 'user');

-- Create user_roles table for secure role management
CREATE TABLE public.user_roles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
    role app_role NOT NULL DEFAULT 'user',
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    UNIQUE (user_id, role)
);

-- Enable RLS on user_roles
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

-- Create security definer function to check roles
CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role app_role)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE user_id = _user_id
      AND role = _role
  )
$$;

-- Create profiles table
CREATE TABLE public.profiles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL UNIQUE,
    name TEXT NOT NULL,
    email TEXT NOT NULL,
    organization_name TEXT,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- Create events table
CREATE TABLE public.events (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
    name TEXT NOT NULL,
    description TEXT,
    event_date DATE NOT NULL,
    template_url TEXT,
    template_fields JSONB DEFAULT '[]'::jsonb,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.events ENABLE ROW LEVEL SECURITY;

-- Create participants table
CREATE TABLE public.participants (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    event_id UUID REFERENCES public.events(id) ON DELETE CASCADE NOT NULL,
    name TEXT NOT NULL,
    email TEXT NOT NULL,
    phone TEXT,
    unique_id TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.participants ENABLE ROW LEVEL SECURITY;

-- Create certificates table
CREATE TABLE public.certificates (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    certificate_id TEXT NOT NULL UNIQUE,
    event_id UUID REFERENCES public.events(id) ON DELETE CASCADE NOT NULL,
    participant_id UUID REFERENCES public.participants(id) ON DELETE CASCADE NOT NULL,
    pdf_url TEXT,
    qr_url TEXT,
    issued_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    downloaded_count INTEGER DEFAULT 0
);

ALTER TABLE public.certificates ENABLE ROW LEVEL SECURITY;

-- RLS Policies for profiles
CREATE POLICY "Users can view own profile" ON public.profiles
FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can update own profile" ON public.profiles
FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own profile" ON public.profiles
FOR INSERT WITH CHECK (auth.uid() = user_id);

-- RLS Policies for user_roles
CREATE POLICY "Users can view own roles" ON public.user_roles
FOR SELECT USING (auth.uid() = user_id);

-- RLS Policies for events (admin only)
CREATE POLICY "Admins can view own events" ON public.events
FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Admins can create events" ON public.events
FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Admins can update own events" ON public.events
FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Admins can delete own events" ON public.events
FOR DELETE USING (auth.uid() = user_id);

-- RLS Policies for participants
CREATE POLICY "Admins can view participants of own events" ON public.participants
FOR SELECT USING (
    EXISTS (SELECT 1 FROM public.events WHERE events.id = participants.event_id AND events.user_id = auth.uid())
);

CREATE POLICY "Admins can create participants for own events" ON public.participants
FOR INSERT WITH CHECK (
    EXISTS (SELECT 1 FROM public.events WHERE events.id = participants.event_id AND events.user_id = auth.uid())
);

CREATE POLICY "Admins can update participants of own events" ON public.participants
FOR UPDATE USING (
    EXISTS (SELECT 1 FROM public.events WHERE events.id = participants.event_id AND events.user_id = auth.uid())
);

CREATE POLICY "Admins can delete participants of own events" ON public.participants
FOR DELETE USING (
    EXISTS (SELECT 1 FROM public.events WHERE events.id = participants.event_id AND events.user_id = auth.uid())
);

-- RLS Policies for certificates
CREATE POLICY "Admins can view certificates of own events" ON public.certificates
FOR SELECT USING (
    EXISTS (SELECT 1 FROM public.events WHERE events.id = certificates.event_id AND events.user_id = auth.uid())
);

CREATE POLICY "Anyone can view certificates by certificate_id" ON public.certificates
FOR SELECT USING (true);

CREATE POLICY "Admins can create certificates for own events" ON public.certificates
FOR INSERT WITH CHECK (
    EXISTS (SELECT 1 FROM public.events WHERE events.id = certificates.event_id AND events.user_id = auth.uid())
);

CREATE POLICY "Admins can delete certificates of own events" ON public.certificates
FOR DELETE USING (
    EXISTS (SELECT 1 FROM public.events WHERE events.id = certificates.event_id AND events.user_id = auth.uid())
);

-- Function to update timestamps
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Triggers for updated_at
CREATE TRIGGER update_profiles_updated_at
BEFORE UPDATE ON public.profiles
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_events_updated_at
BEFORE UPDATE ON public.events
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Create storage buckets
INSERT INTO storage.buckets (id, name, public) VALUES ('templates', 'templates', true);
INSERT INTO storage.buckets (id, name, public) VALUES ('certificates', 'certificates', true);

-- Storage policies for templates
CREATE POLICY "Authenticated users can upload templates"
ON storage.objects FOR INSERT
WITH CHECK (bucket_id = 'templates' AND auth.role() = 'authenticated');

CREATE POLICY "Anyone can view templates"
ON storage.objects FOR SELECT
USING (bucket_id = 'templates');

CREATE POLICY "Users can update own templates"
ON storage.objects FOR UPDATE
USING (bucket_id = 'templates' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can delete own templates"
ON storage.objects FOR DELETE
USING (bucket_id = 'templates' AND auth.uid()::text = (storage.foldername(name))[1]);

-- Storage policies for certificates
CREATE POLICY "Authenticated users can upload certificates"
ON storage.objects FOR INSERT
WITH CHECK (bucket_id = 'certificates' AND auth.role() = 'authenticated');

CREATE POLICY "Anyone can view certificates"
ON storage.objects FOR SELECT
USING (bucket_id = 'certificates');

-- Function to auto-create profile on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO public.profiles (user_id, name, email)
    VALUES (NEW.id, COALESCE(NEW.raw_user_meta_data->>'name', 'User'), NEW.email);
    
    INSERT INTO public.user_roles (user_id, role)
    VALUES (NEW.id, 'admin');
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger for new user signup
CREATE TRIGGER on_auth_user_created
AFTER INSERT ON auth.users
FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();