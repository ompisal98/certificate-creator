import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface TemplateField {
  id: string;
  name: string;
  x: number;
  y: number;
  fontSize: number;
  fontFamily: string;
  color: string;
  fontWeight: string;
}

interface GenerateCertificateRequest {
  eventId: string;
  participantIds?: string[];
}

// Generate QR code as SVG string (no canvas needed)
function generateQRCodeSVG(data: string, size: number = 120): string {
  // Simple QR code placeholder - we'll generate actual QR on frontend
  // This returns a data URL for an SVG placeholder
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${size} ${size}" width="${size}" height="${size}">
    <rect width="100%" height="100%" fill="white"/>
    <text x="50%" y="50%" text-anchor="middle" dominant-baseline="middle" font-size="10" fill="#666">QR Code</text>
  </svg>`;
  return `data:image/svg+xml;base64,${btoa(svg)}`;
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const { eventId, participantIds }: GenerateCertificateRequest = await req.json();
    console.log(`Generating certificates for event: ${eventId}`);

    // Get event details
    const { data: event, error: eventError } = await supabase
      .from("events")
      .select("*")
      .eq("id", eventId)
      .single();

    if (eventError || !event) {
      console.error("Event not found:", eventError);
      return new Response(JSON.stringify({ error: "Event not found" }), {
        status: 404,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (!event.template_url) {
      return new Response(JSON.stringify({ error: "No template uploaded for this event" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Get participants
    let participantsQuery = supabase
      .from("participants")
      .select("*")
      .eq("event_id", eventId);

    if (participantIds && participantIds.length > 0) {
      participantsQuery = participantsQuery.in("id", participantIds);
    }

    const { data: participants, error: participantsError } = await participantsQuery;

    if (participantsError || !participants || participants.length === 0) {
      console.error("No participants found:", participantsError);
      return new Response(JSON.stringify({ error: "No participants found" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Check which participants already have certificates
    const { data: existingCerts } = await supabase
      .from("certificates")
      .select("participant_id")
      .eq("event_id", eventId);

    const existingParticipantIds = new Set(existingCerts?.map(c => c.participant_id) || []);
    const newParticipants = participants.filter(p => !existingParticipantIds.has(p.id));

    if (newParticipants.length === 0) {
      return new Response(JSON.stringify({ 
        message: "All participants already have certificates",
        generated: 0 
      }), {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const templateFields: TemplateField[] = Array.isArray(event.template_fields) 
      ? event.template_fields 
      : [];

    const generatedCertificates = [];
    const baseUrl = req.headers.get("origin") || "https://certifypro.lovable.app";

    for (const participant of newParticipants) {
      const certificateId = `CERT-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`;
      const verifyUrl = `${baseUrl}/verify?id=${certificateId}`;

      // Store certificate in database
      const { data: cert, error: certError } = await supabase
        .from("certificates")
        .insert({
          certificate_id: certificateId,
          event_id: eventId,
          participant_id: participant.id,
          qr_url: verifyUrl,
        })
        .select()
        .single();

      if (certError) {
        console.error(`Error creating certificate for ${participant.name}:`, certError);
        continue;
      }

      generatedCertificates.push({
        ...cert,
        participantName: participant.name,
        participantEmail: participant.email,
      });
    }

    console.log(`Generated ${generatedCertificates.length} certificates`);

    return new Response(JSON.stringify({ 
      message: `Generated ${generatedCertificates.length} certificates`,
      generated: generatedCertificates.length,
      certificates: generatedCertificates,
    }), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error: unknown) {
    console.error("Error generating certificates:", error);
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    return new Response(JSON.stringify({ error: errorMessage }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
