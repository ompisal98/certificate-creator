import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";
import { Resend } from "https://esm.sh/resend@2.0.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface SendCertificatesRequest {
  eventId: string;
  certificateIds?: string[];
}

const resend = new Resend(Deno.env.get("RESEND_API_KEY"));

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const { eventId, certificateIds }: SendCertificatesRequest = await req.json();
    console.log(`Sending certificates for event: ${eventId}`);

    // Get event details
    const { data: event, error: eventError } = await supabase
      .from("events")
      .select("*")
      .eq("id", eventId)
      .single();

    if (eventError || !event) {
      console.error("Event not found:", eventError);
      return new Response(JSON.stringify({ error: "Event not found" }), {
        status: 404,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Get certificates with participant info
    let certsQuery = supabase
      .from("certificates")
      .select(`
        *,
        participants (name, email)
      `)
      .eq("event_id", eventId);

    if (certificateIds && certificateIds.length > 0) {
      certsQuery = certsQuery.in("certificate_id", certificateIds);
    }

    const { data: certificates, error: certsError } = await certsQuery;

    if (certsError || !certificates || certificates.length === 0) {
      console.error("No certificates found:", certsError);
      return new Response(JSON.stringify({ error: "No certificates found" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const baseUrl = req.headers.get("origin") || "https://certifypro.lovable.app";
    let sentCount = 0;
    let failedCount = 0;
    const errors: string[] = [];

    for (const cert of certificates) {
      const participant = cert.participants;
      if (!participant?.email) {
        console.error(`No email for certificate ${cert.certificate_id}`);
        failedCount++;
        errors.push(`No email for ${cert.certificate_id}`);
        continue;
      }

      const verifyUrl = `${baseUrl}/verify?id=${cert.certificate_id}`;
      const downloadUrl = `${baseUrl}/certificates?download=${cert.certificate_id}`;

      try {
        const { error: emailError } = await resend.emails.send({
          from: "CertifyPro <onboarding@resend.dev>",
          to: [participant.email],
          subject: `Your Certificate for ${event.name}`,
          html: `
            <!DOCTYPE html>
            <html>
            <head>
              <meta charset="utf-8">
              <meta name="viewport" content="width=device-width, initial-scale=1.0">
            </head>
            <body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
              <div style="text-align: center; margin-bottom: 30px;">
                <h1 style="color: #14b8a6; margin: 0;">🎓 CertifyPro</h1>
              </div>
              
              <div style="background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%); color: white; padding: 30px; border-radius: 12px; margin-bottom: 20px;">
                <h2 style="margin: 0 0 10px 0; color: #14b8a6;">Congratulations, ${participant.name}!</h2>
                <p style="margin: 0; opacity: 0.9;">Your certificate for <strong>${event.name}</strong> is ready.</p>
              </div>
              
              <div style="background: #f8fafc; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
                <p style="margin: 0 0 10px 0;"><strong>Certificate ID:</strong> ${cert.certificate_id}</p>
                <p style="margin: 0 0 10px 0;"><strong>Event Date:</strong> ${new Date(event.event_date).toLocaleDateString()}</p>
                <p style="margin: 0;"><strong>Issued:</strong> ${new Date(cert.issued_at).toLocaleDateString()}</p>
              </div>
              
              <div style="text-align: center; margin: 30px 0;">
                <a href="${verifyUrl}" style="display: inline-block; background: #14b8a6; color: white; padding: 12px 30px; border-radius: 8px; text-decoration: none; font-weight: 600; margin: 5px;">View Certificate</a>
              </div>
              
              <p style="color: #64748b; font-size: 14px; text-align: center;">
                You can verify your certificate anytime by visiting the verification page and entering your Certificate ID.
              </p>
              
              <hr style="border: none; border-top: 1px solid #e2e8f0; margin: 30px 0;">
              
              <p style="color: #94a3b8; font-size: 12px; text-align: center; margin: 0;">
                This email was sent by CertifyPro. If you have any questions, please contact the event organizer.
              </p>
            </body>
            </html>
          `,
        });

        if (emailError) {
          console.error(`Failed to send email to ${participant.email}:`, emailError);
          failedCount++;
          errors.push(`Failed to send to ${participant.email}: ${emailError.message}`);
        } else {
          sentCount++;
          console.log(`Email sent to ${participant.email}`);
        }
      } catch (emailErr: unknown) {
        console.error(`Error sending email to ${participant.email}:`, emailErr);
        failedCount++;
        const errMsg = emailErr instanceof Error ? emailErr.message : "Unknown error";
        errors.push(`Error sending to ${participant.email}: ${errMsg}`);
      }
    }

    console.log(`Sent ${sentCount} emails, ${failedCount} failed`);

    return new Response(JSON.stringify({ 
      message: `Sent ${sentCount} emails successfully`,
      sent: sentCount,
      failed: failedCount,
      errors: errors.length > 0 ? errors : undefined,
    }), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error: unknown) {
    console.error("Error sending certificates:", error);
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    return new Response(JSON.stringify({ error: errorMessage }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
