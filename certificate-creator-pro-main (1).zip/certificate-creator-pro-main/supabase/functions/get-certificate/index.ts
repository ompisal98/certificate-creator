import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const url = new URL(req.url);
    const certificateId = url.searchParams.get("id");

    if (!certificateId) {
      return new Response(JSON.stringify({ error: "Certificate ID is required" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    console.log(`Fetching certificate: ${certificateId}`);

    // Get certificate with related data
    const { data: certificate, error: certError } = await supabase
      .from("certificates")
      .select(`
        *,
        participants (name, email),
        events (name, event_date, description, template_url, template_fields)
      `)
      .eq("certificate_id", certificateId)
      .single();

    if (certError || !certificate) {
      console.error("Certificate not found:", certError);
      return new Response(JSON.stringify({ error: "Certificate not found" }), {
        status: 404,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const baseUrl = req.headers.get("origin") || "https://certifypro.lovable.app";
    const verifyUrl = `${baseUrl}/verify?id=${certificateId}`;

    // Return certificate data for rendering (QR will be generated on frontend)
    const certificateData = {
      certificateId: certificate.certificate_id,
      participantName: certificate.participants?.name,
      participantEmail: certificate.participants?.email,
      eventName: certificate.events?.name,
      eventDate: certificate.events?.event_date,
      eventDescription: certificate.events?.description,
      templateUrl: certificate.events?.template_url,
      templateFields: certificate.events?.template_fields || [],
      verifyUrl,
      issuedAt: certificate.issued_at,
    };

    // Increment download count
    await supabase
      .from("certificates")
      .update({ downloaded_count: (certificate.downloaded_count || 0) + 1 })
      .eq("id", certificate.id);

    console.log(`Certificate fetched successfully: ${certificateId}`);

    return new Response(JSON.stringify(certificateData), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error: unknown) {
    console.error("Error fetching certificate:", error);
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    return new Response(JSON.stringify({ error: errorMessage }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
